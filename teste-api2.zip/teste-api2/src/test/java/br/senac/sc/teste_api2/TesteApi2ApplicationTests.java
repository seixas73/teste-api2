package br.senac.sc.teste_api2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteApi2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
